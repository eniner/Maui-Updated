---
npc: "Rumble"
zone: "Guild Lobby"
zone_short: "guildlobby"
first_seen: "2026-04-13T16:23:19Z"
response_count: 13
---

# Rumble

Zone: Guild Lobby

## Overview

- I can no longer provide you with talents once you have reached level 75!
- Titles reloaded for PID (5109) Befallen (36).
- Titles reloaded for PID (5799) Temple of Bertoxxulous (469) (Instance ID 109).
- Titles reloaded for PID (5907) Brell's Arena (492) (Instance ID 110).
- Titles reloaded for PID (163) The Estate of Unrest (63).
- Titles reloaded for PID (158) Firiona Vie (84).
- Titles reloaded for PID (881) Ocean of Tears (69) (Instance ID 52).
- Titles reloaded for PID (161) Guild Lobby (344).
- Titles reloaded for PID (178) Velketor's Labyrinth (112) (Instance ID 324).
- Titles reloaded for PID (518) Ocean of Tears (69) (Instance ID 51).
- Titles reloaded for PID (167) Velketor's Labyrinth (112) (Instance ID 325).
- Titles reloaded for PID (7866) Crushbone (58) (Instance ID 111).
- Titles reloaded for PID (7120) The Elddar Forest (378).

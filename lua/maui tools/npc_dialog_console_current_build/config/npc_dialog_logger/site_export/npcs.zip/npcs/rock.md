---
npc: "Rock"
zone: "Guild Lobby"
zone_short: "guildlobby"
first_seen: "2026-04-13T16:22:06Z"
response_count: 2
---

# Rock

Zone: Guild Lobby

## Overview

- I can only assist those under level 75!
- Ultimate Pets are now automatically buffed if your class can inherently summon pets and you have specialized in Destruction. You no longer need the Ultimate Pet Buff.
